Author: Vikram Dudee

Course: CS 463G

Date submitted: 9-7-2016

Collaboration: None, except for looking at pictures of what the puzzle looks like online.

Technical Problems: will perform the first few steps well then will completely freak out and put random characters in 2D array.
This may be because of me making an slight error in incorporating the logic of the balls actually falling where and when they
should in the fallLogic(char** b, char** t) function. It also could have something to do with array allocation/pointers because
the arrays sometimes "lose size."

Heuristic Value Calculation: I decided to calculate the heuristic value by increasing a universal count when: a red ball (R) was
in the bottom 6-space tube, a green ball (G) was in the bottom 5-space tube, a yellow ball (Y) was in the bottom 4-space tube, a blue
ball (B) was in the bottom 3-space tube, a white ball (W) was in the bottom 2-space tube, and a purple ball bottom (P) was in the
1-space tube. This count was then deducted from 21 (the maximum possible places in the bottom tubes you can have the correct ball) to
arrive at the heuristic value: 0 being solved and 21 being among the furthest from solved scenarios.
