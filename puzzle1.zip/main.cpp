#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

int shiftInd = 0; //made global variable so I don't have to deal with *'s
int inverted = 0; //0 is not upside down, 1 is upside down.
int hVal;

void fallLogic(char** b, char** t){
	int space;
	int topspace;
	int aftShift;
	if(inverted == 0){//t[i-shiftInd] falls into b[i]
		for(int i=0; i<6; i++){
			space = 0;//resetting free space count
			topspace = 0;
			aftShift = i+shiftInd;
			if(aftShift>=6)
				aftShift%=6;
			if(aftShift<0)
				aftShift+=6;
			for(int j=0; j<(6-i); j++){
				if(b[i][j]=='-')
					space++;
			}//end inner
			if(b[i][0]=='-'&&space!=0)//downtube shift
				for(int p=0; p<(6-i-space); p++){
					b[i][p]=b[i][p+space];
					b[i][p+space]='-';
				}
			for(int m=0; m<(6-aftShift); m++){
				if(t[aftShift][m]=='-')
					topspace++;
			}
//			cout << "drop " << space << " into bottom tube[" << i << "]" << endl;
			//move balls here

			if(topspace!=0&&t[aftShift][0]=='-'){//uptube shift
				for(int x=0; x<(6-aftShift-topspace); x++){
					t[aftShift][x]=t[aftShift][x+topspace];
					t[aftShift][x+topspace] = '-';
				}
			}
			if(space!=0){
				for(int l=0; l<(12-i-aftShift-space); l++){//tube transfer shift
					if(l<space){
						b[i][6-i-space+l]=t[aftShift][l];
						t[aftShift][l] = '-';
					}
					if(l>=space){
						t[aftShift][(l-space)]=t[aftShift][l];
						t[aftShift][l] = '-';
					}
				}
			}
		}//end outer for-loop
	}
	else{//b[i] falls into t[i-shiftInd]
		for(int h=0; h<6; h++){
			space = 0;
			topspace = 0;
			aftShift = h+shiftInd;
			if(aftShift>=6)
				aftShift%=6;
			if(aftShift<0)
				aftShift+=6;
			for(int j=0; j<(6-aftShift); j++){
				if(t[aftShift][j]=='-')
					space++;
			}//end inner
			if(t[aftShift][6-aftShift-1]=='-'&&space!=0)//downtube shift
				for(int r=0; r<(6-aftShift-space); r++){
					t[aftShift][6-aftShift-1-r]=t[aftShift][6-aftShift-r-1-space];
					t[aftShift][6-aftShift-r-1-space]='-';
				}
			for(int m=0; m<(6-h); m++){
				if(b[h][m]=='-')
					topspace++;
			}
//			cout << "drop " << space << " into top tube[" << aftShift << "]" << endl;
			//move balls here
			//(12-h-aftShift)-(6-aftShift-space)= combined capacities of alligned tubes minus balls that dont need to move
			//ends up equaling (6-h+space) which is the total number of ball position changes needed for this set of aligned tubes.
			if(topspace!=0&&b[h][6-h-1]=='-'){//uptube shift
				for(int x=0; x<(6-h-topspace); x++){
					b[h][6-h-1-x]=b[h][6-h-1-x-topspace];
					b[h][6-h-1-x-topspace]='-';
				}

			}

			if(space!=0){
				for(int l=0; l<(12-h-aftShift-space); l++){//tube transfer shift
					if(l<space){
						t[aftShift][space-l-1] = b[h][6-h-1-l];
						b[h][6-h-1-l] = '-';
					}
					if(l>=space){
						b[h][6-h-1-l+space] = b[h][6-h-l-1];
						b[h][6-h-l-1] = '-';
					}
				}
			}
		}//end outer for-loop
	}
}

void printState(char** b, char** t){
	int aftShift;
	char colors[6] = {'R', 'G', 'Y', 'B', 'W', 'P'};
	hVal = 0;
	cout << endl << "Current state: " << endl;
	for(int i=0; i<6; i++){
		aftShift = i+shiftInd;
		if(aftShift>=6)
			aftShift%=6;
		if(aftShift<0)
			aftShift+=6;
		for(int l=0; l<i; l++)
			cout << " ";
		for(int j=0; j<(6-i); j++)
			cout << b[i][j];
		cout << "|";
		for(int k=0; k<(6-aftShift); k++)
			cout << t[aftShift][k];
		cout << "" << endl;
	}
	for(int q=0; q<6; q++){
		for(int w=0; w<(6-q); w++)
			if(b[q][w]==colors[q])
				hVal++;
	}
	if(inverted==0)
		cout << "This way is up ->" << endl;
	else
		cout << "<- This way is up" << endl;
	hVal=(21-hVal);
	cout << "Variable 'inverted' = " << inverted << endl;
	cout << "Heuristic Value is: " << hVal << " (0 is solved, 21 is the most scrambled.)" << endl;
	cout << "" << endl;
}

void rotateCCW(char** b, char** t){
	shiftInd--;
	if(shiftInd<0)
		shiftInd+=6;
	if(shiftInd>=6)
		shiftInd%=6;
//	cout << "Rotated counter-clockwise." << endl << endl;
	fallLogic(b, t);

}

void rotateCW(char** b, char** t){
	shiftInd++;
	if(shiftInd>=6)
		shiftInd%=6;
	if(shiftInd<0)
		shiftInd+=6;
//	cout << "Rotated clockwise." << endl << endl;
	fallLogic(b, t);
}

void flip(char** b, char** t){
	if(inverted==1)
		inverted = 0;
	else
		inverted = 1;
	fallLogic(b, t);
	//make changes to ball position based on logic here^
}

void randomize(char** b, char** t){
	int r;
	for(int i=0; i<1000; i++){//will perform 1000 random operations
		r = rand()%3;
		if(r==0)
			rotateCCW(b, t);
		if(r==1)
			rotateCW(b, t);
		if(r==2)
			flip(b, t);
	}
}

int main(){
/*
to begin the structure of this simulated atomic puzzle structure,
I will create 12 arrays, each with a defined capacity depending on which tube
they represent: 6 bottom tubes, 6 corresponding top tubes as well as "shift index"
to help keep track of which tubes are over which. The "shift index" will be 0 when
all the tubes are over the tube with the same capacity as them (their twin on the other side)
The balls will be represented with characters; to avoid confusion with blue and black, black is
replaced with Purple (P). There are 6 red balls (R), 5 green (G), 4 Yellow (Y), 3 blue (B),
2 white (W), and 1 purple (P). Void spaces are represented with "-".
*/


//Original bottom tubes
	char *bottom[6];//making 2D with pointer to char arrays so they
//each can have different capacities

	char sixBot[6] = {'R', 'R', 'R', 'R', 'R', 'R'};
	char fiveBot[5] = {'G', 'G', 'G', 'G', 'G'};
	char fourBot[4] = {'Y', 'Y', 'Y', 'Y'};
	char threeBot[3] = {'B', 'B', 'B'};
	char twoBot[2] = {'W', 'W'};
	char oneBot[1] = {'P'};

	bottom[0] = sixBot;
	bottom[1] = fiveBot;
	bottom[2] = fourBot;
	bottom[3] = threeBot;
	bottom[4] = twoBot;
	bottom[5] = oneBot;

//Original top tubes
	char *top[6]; //making them into a 2D array like up there^

	char sixTop[6] = {'-', '-', '-', '-', '-', '-'};
	char fiveTop[5] = {'-', '-', '-', '-', '-'};
	char fourTop[4] = {'-', '-', '-', '-'};
	char threeTop[3] = {'-', '-', '-'};
	char twoTop[2] = {'-', '-'};
	char oneTop[1] = {'-'};

	top[0] = sixTop;
	top[1] = fiveTop;
	top[2] = fourTop;
	top[3] = threeTop;
	top[4] = twoTop;
	top[5] = oneTop;

	string inp = "";
	printState(bottom, top);
	while(inp!="6"){
		cout << "Please enter the number corresponding with what you wish to do." << endl;
		cout << "1 - Print current state of puzzle." << endl;
		cout << "2 - Rotate top half counter-clockwise." << endl;
		cout << "3 - Rotate top half clockwise." << endl;
		cout << "4 - Flip puzzle." << endl;
		cout << "5 - Randomize puzzle" << endl;
		cout << "6 - Exit puzzle simulator." << endl << endl;
		cin >> inp;

		if(inp == "1")
			printState(bottom, top);
		else if(inp == "2")
			rotateCCW(bottom, top);
		else if(inp == "3")
			rotateCW(bottom, top);
		else if(inp == "4")
			flip(bottom, top);
		else if(inp == "5")
			randomize(bottom, top);
		else if(inp!= "6")
			cout << "Invalid input, please try again." << endl;
	}

}
